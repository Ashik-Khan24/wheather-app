package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    EditText name,email,phone,tablenum;
    Button order,b1;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);

        name=findViewById(R.id.name);
        order=findViewById(R.id.order);
        phone=findViewById(R.id.phone);
        order=findViewById(R.id.order);
        email=findViewById(R.id.email);
        tablenum=findViewById(R.id.tablenum);

        db=openOrCreateDatabase("mydb",MODE_PRIVATE,null);
        try {
            db.execSQL("create table if not exists reserve(name varchar(20),email varchar(40),phone varchar(100),tablenum varchar(10))");
            Toast.makeText(getApplicationContext(),"table created",Toast.LENGTH_LONG).show();
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"table creation failed",Toast.LENGTH_LONG).show();
        }

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String n=name.getText().toString();
                String mail=email.getText().toString();
                String ph=phone.getText().toString();
                String tbale=tablenum.getText().toString();
                try {
                    String insertQuery= "insert into problem values('"+n+"','"+mail+"','"+ph+"','"+tbale+"');";
                    db.execSQL(insertQuery);
                    Toast.makeText(getApplicationContext(),"order completed",Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(Reservation.this,MainActivity.class);
                    startActivity(intent);
                    finish();

                }catch (Exception e){
                    Toast.makeText(getApplicationContext(),"order failed",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}


