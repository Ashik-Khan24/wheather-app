package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    Button aprevious, anext;

    TextView aexpense;

    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        aprevious = findViewById(R.id.aprevious);
        anext = findViewById(R.id.anext);

        aexpense = findViewById(R.id.aexpense);

        db = openOrCreateDatabase("Mydb", MODE_PRIVATE, null);
        final Cursor c = db.rawQuery("select * from Expense", null);
        c.moveToFirst();

        aexpense.setText(c.getString(c.getColumnIndex("value")));

        aprevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    c.moveToPrevious();
                    aexpense.setText(c.getString(c.getColumnIndex("value")));
                } catch (Exception e){
                    Toast.makeText(getApplication(), "First Row", Toast.LENGTH_SHORT).show();
                }

            }
        });

        anext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    c.moveToNext();
                    aexpense.setText(c.getString(c.getColumnIndex("Value")));

                } catch (Exception e){
                    Toast.makeText(getApplication(), "Last Row", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}